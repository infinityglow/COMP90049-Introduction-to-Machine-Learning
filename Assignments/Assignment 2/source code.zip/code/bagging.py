import random

from preprocess import *

base_dir = '../dataset'

def sample(mode):

    if mode == 'train':
        sub_dir_x = '/train_features.csv'
        sub_dir_y = '/train_labels.csv'
    elif mode == 'val':
        sub_dir_x = '/valid_features.csv'
        sub_dir_y = '/valid_labels.csv'
    else:
        sub_dir_x = '/test_features.csv'
        x = read_csv(base_dir + sub_dir_x)
        return x.sample(frac=1, replace=True)

    x, y = read_csv(base_dir + sub_dir_x), read_csv(base_dir + sub_dir_y)
    dataset = pd.concat([x, y], axis=1)
    sampled_dataset = dataset.sample(frac=1, replace=True)
    x, y = sampled_dataset.iloc[:, :-2], sampled_dataset.iloc[:, -2:]
    return x, y

def evaluate(y_preds_list, base_dir):
    # predict final prediction by voting
    y_val = read_csv(base_dir+'/valid_labels.csv')
    y_val = get_label(y_val)
    y_val = label2idx(y_val)
    y_preds_concat = y_preds_list
    for y_preds in y_preds_list[1:]:
        y_preds_concat = np.concatenate((y_preds_concat, y_preds), axis=1)
    y_preds_final = np.array([[np.argmax(np.bincount(y_preds))] for y_preds in y_preds_concat])
    acc = sum(y_preds_final.squeeze() == y_val) / float(y_val.shape[0])
    return acc

import pandas as pd
import numpy as np
from build_vocab import Vocabulary

def read_csv(dir):
    data = pd.read_csv(dir)
    return data

def splitFeatures(x):
    # metadata features extraction
    meta = np.array(x[['loudness', 'tempo', 'duration', 'time_signature', 'key', 'mode']])

    # textual features extraction
    text = np.array(x[['tags']])
    text = np.array([[t[0].lower().split(', ')] for t in text])
    words = []
    for t in text:
        words += t[0]
    words = set(words)
    vocab = Vocabulary()
    vocab.add('<unk>')
    for word in words:
        vocab.add(word)


    # audio features extraction
    audio = np.array(x.iloc[:, 9:], dtype=np.float)

    # normalization
    audio_mean = np.mean(audio, axis=0, keepdims=True)  # mean value μ_i for each attribute
    audio_std = np.std(audio, axis=0, keepdims=True)  # standard deviation σ_i for each attribute
    audio = (audio - audio_mean) / audio_std  # x_i = (x_i - μ_i) / σ_i with 0 mean and 1 variance
    return (meta, (text, vocab), audio)

def get_label(y):
    labels = np.array(y[['genre']])
    return labels

def label2idx(labels):
    vocab = {'soul and reggae': 0, 'pop': 1, 'punk': 2, 'jazz and blues': 3, 'dance and electronica': 4, 'folk': 5,
             'classic pop and rock': 6, 'metal': 7}
    indices = np.array([vocab[label[0]] for label in labels])
    return indices

def idx2label(indices):
    vocab = {0: 'soul and reggae', 1: 'pop', 2: 'punk', 3: 'jazz and blues', 4: 'dance and electronica', 5: 'folk',
             6: 'classic pop and rock', 7: 'metal'}
    labels = np.array([vocab[idx] for idx in indices])
    return labels

def idx2oh(indices, num_class):
    indices_flat = np.squeeze(indices)  # reduce to 1D
    one_hot = np.eye(num_class)[indices_flat]
    return one_hot

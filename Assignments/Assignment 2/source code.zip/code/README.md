## Details of The Implementation

### build_vocab.py
  `build_vocab.py` is to build a vocabulary that maps from a word to an index and an index to a word. If there is an unknown word during evaluation, we replace it with a token `<unk>`.
   
### nn.py
   `nn.py` is the construction of a neural network, and it is implemented by PyTorch.

### preprocess.py
   `preprocess.py` preprocesses raw data with the data type `Dataframe` to three parts, namely `x_meta`, `x_text` and `x_audio`.
   
### train.py
   `train.py` is the backbone of training phrase. It consists of training neural network and calculate the parameters of Naive Bayes and multinomial event model.
   
### validation.py
   `validation.py` calculates the probability distribution over entire class labels for both neural network part and weighted Naive Bayes part.
   
### test.py
   `test.py` predicts class labels of 'test_features.csv'. It mainly call function `predict` in `validation.py`.
   
### bagging.py
   `bagging.py` has two functions, one is `sample`, which randomly samples a dataset with the same size of the original dataset; another one is `evaluate`, which takes predicted labels and output final class labels using ensembling method.
   
### plot.py
   `plot.py` draws figures like feature value distribution, illustration of improvement on bagging and confusion matrix.
   
### main.py
   `main.py` is the main controller of all previous functions, mainly used for tuning parameters and evaluation.
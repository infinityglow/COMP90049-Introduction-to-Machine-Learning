import matplotlib.pyplot as plt
from preprocess import *
from sklearn.metrics import confusion_matrix
import numpy as np
import torch
from validation import predict


base_dir = '../dataset'
#
# x_train, y_train = read_csv(base_dir+'/train_features.csv'), read_csv(base_dir+'/train_labels.csv')
# x_meta, (x_text, vocab), x_audio = splitFeatures(x_train)
# audio = np.array(x_train.iloc[:, 9:], dtype=np.float)
#
# fig = plt.figure(figsize=(6, 3), dpi=200)
# ax = fig.add_subplot(121)
# ax.spines['top'].set_color('none')
# ax.spines['right'].set_color('none')
# ax.xaxis.set_ticks_position('bottom')
# ax.spines['bottom'].set_position(('data', 0))
# ax.yaxis.set_ticks_position('left')
# ax.spines['left'].set_position(('data', 0))
# plt.xticks([-80, -60, -40, -20, 0, 20, 40, 60, 80], fontsize=5)
# plt.yticks([-50, -25, 25, 50], fontsize=5)
# plt.scatter(audio[:1500, 4].squeeze()+50, audio[:1500, 3].squeeze()+20, s=4, c='y', alpha=0.6)
# plt.xlim((-100, 100))
# plt.ylim((-60, 60))
# plt.title('Before Normalization', fontdict={'size': 8})
#
# ax = fig.add_subplot(122)
# ax.spines['top'].set_color('none')
# ax.spines['right'].set_color('none')
# ax.xaxis.set_ticks_position('bottom')
# ax.spines['bottom'].set_position(('data', 0))
# ax.yaxis.set_ticks_position('left')
# ax.spines['left'].set_position(('data', 0))
# plt.xticks([-4, -3, -2, -1, 0, 1, 2, 3, 4], fontsize=5)
# plt.yticks([-4, -3, -2, -1, 1, 2, 3, 4], fontsize=5)
# plt.scatter(x_audio[:1500, 4].squeeze(), x_audio[:1500, 3].squeeze(), s=4, c='teal', alpha=0.6)
# plt.title('After Normalization', fontdict={'size': 8})

# plt.savefig('../figure/normal.jpg')

# x = [5, 10, 15, 20]
# height = [0.467, 0.508, 0.532, 0.602]
# plt.bar(x, height, 1, color='salmon', )
# plt.xticks([5, 10, 15, 20], ['baseline', '$n=3$', '$n=5$', '$n=10$'])
# plt.yticks([i/10 for i in range(11)], ['%d%%' % i for i in range(0, 110, 10)])
# plt.xlim((2, 23))
# plt.text(3.25, 1.09, 'test accuracy for different sized bagging models', fontdict={'size': 13.5})
# plt.text(23.5, -0.01, 'model')
# plt.text(-0.5, 1.05, 'accuracy(%)', fontdict={'size': 10})
#
# for a, b in zip(x, height):
#     plt.text(a, b+0.02, '%.1f%%' % (100*b), ha='center', va='bottom')
#
# plt.savefig('../figure/test accuracy.jpg')

MODEL_PATH = '../model/model_list'
PARAMS_PATH = '../model/params_list.npy'
HYPER_PARAMS_PATH = '../model/hyper_params_list.npy'

x_val, y_val = read_csv(base_dir+'/valid_features.csv'), read_csv(base_dir+'/valid_labels.csv')
y_val = get_label(y_val)
y_val = label2idx(y_val)
model = torch.load(MODEL_PATH)
hyperparams = np.load(HYPER_PARAMS_PATH, allow_pickle=True)
params = np.load(PARAMS_PATH, allow_pickle=True)

best_weight_nb = hyperparams[0]['best_weight_nb']
best_weight_combine = hyperparams[0]['best_weight_combine']
y_preds = predict(model, params, base_dir, best_weight_nb, best_weight_combine).squeeze()

labels = ['soul and reggae', 'pop', 'punk', 'jazz and blues', 'dance and electronica', 'folk', 'classic pop and rock', 'metal']

tick_marks = np.array(range(len(labels))) + 0.5

def plot_confusion_matrix(cm, title='Confusion Matrix', cmap=plt.cm.binary):
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.text(2, -1.1, title, fontdict={'size': 18})
    plt.colorbar()
    xlocations = np.array(range(len(labels)))
    plt.xticks(xlocations, labels, rotation=90)
    plt.yticks(xlocations, labels)
    plt.text(7.5, 8, 'predicted label', fontdict={'size': 12})
    plt.text(-1.8, -0.6, 'true label', fontdict={'size': 12})

cm = confusion_matrix(y_val, y_preds)
np.set_printoptions(precision=2)
cm_normalized = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
plt.figure(figsize=(12, 8), dpi=120)

ind_array = np.arange(len(labels))
x, y = np.meshgrid(ind_array, ind_array)

for x_val, y_val in zip(x.flatten(), y.flatten()):
    c = cm_normalized[y_val][x_val]
    if c > 0.01:
        plt.text(x_val, y_val, "%0.2f" % (c,), color='red', fontsize=7, va='center', ha='center')
# offset the tick
plt.gca().set_xticks(tick_marks, minor=True)
plt.gca().set_yticks(tick_marks, minor=True)
plt.gca().xaxis.set_ticks_position('none')
plt.gca().yaxis.set_ticks_position('none')
plt.grid(True, which='minor', linestyle='-')
plt.gcf().subplots_adjust(bottom=0.15)

plot_confusion_matrix(cm_normalized)
# show confusion matrix
plt.savefig('../Figure/confusion_matrix.jpg')
plt.show()

plt.show()

import numpy as np
import pandas as pd
import torch
from bagging import *
from validation import predict
from preprocess import *

MODEL_PATH = '../model/model_list'
PARAMS_PATH = '../model/params_list.npy'
HYPER_PARAMS_PATH = '../model/hyper_params_list.npy'

model_list = torch.load(MODEL_PATH)
hyper_params_dict = np.load(HYPER_PARAMS_PATH, allow_pickle=True)
params = np.load(PARAMS_PATH, allow_pickle=True)

x_test = read_csv('../dataset/test_features.csv')
x_meta, (x_text, _), x_audio = splitFeatures(x_test)

# y_preds = []
# for i in range(len(x_meta)):
#     py, pxy, pxy_ = params
#     class_prob = []
#     for cls in range(len(py)):
#         prob = np.log(py[cls] / sum(py))  # prior probability
#
#         for word in x_text[i][0]:
#             if word not in pxy_[cls]:
#                 prob += np.log(pxy_[cls]['<unk>'])  # word not in vocabulary
#             else:
#                 prob += np.log(pxy_[cls][word])
#         class_prob.append(prob)
#     y_preds.append(class_prob)
# y_preds = np.argmax(y_preds, axis=1)[:, np.newaxis]

y_preds_list_ = []
for i in range(len(model_list)):
    idx = 'model_%d' % i
    model = model_list[idx]
    best_weight_nb = hyper_params_dict[0]['best_weight_nb']
    best_weight_combine = hyper_params_dict[0]['best_weight_combine']
    y_preds = predict(model, params, base_dir, best_weight_nb, best_weight_combine)
    y_preds_list_.append(y_preds)

model = model_list
best_weight_nb = hyper_params_dict[0]['best_weight_nb']
best_weight_combine = hyper_params_dict[0]['best_weight_combine']
y_preds = predict(model, params, base_dir, best_weight_nb, best_weight_combine)

x_test = read_csv('../dataset/test_features.csv')
trackID = x_test['trackID']
ypreds = evaluate(y_preds, base_dir).squeeze()
ypreds = idx2label(ypreds)
ypreds = pd.DataFrame(ypreds, columns=['genre'])
ypreds = pd.concat((trackID, ypreds), axis=1)
ypreds.to_csv('../dataset/test.csv', index=False)





import torch
import numpy as np
from preprocess import *

# This function predicts the class for an instance or a set of instances, based on a trained model
def compute_gaussian(mu, sigma, x):
    return np.exp(-(x - mu)**2 / (2*sigma)) / (np.sqrt(2*np.pi*sigma))

def softmax(x):
    return np.exp(x) / np.sum(np.exp(x), axis=1, keepdims=True)

def predict_nb(x_meta, x_text, params_, weight):
    py, pxy, pxy_ = params_
    y_preds = []
    for i in range(len(x_meta)):
        class_prob = []
        for cls in range(len(py)):
            prob = np.log(py[cls] / sum(py))  # prior probability
            for fidx, f in enumerate(x_meta[i]):
                if fidx < 3:
                    mu, sigma = pxy[cls][fidx]['mu'], pxy[cls][fidx]['sigma']
                    prob += np.log(compute_gaussian(mu, sigma, x_meta[i][fidx]))  # numerical posterior
                else:
                    prob += np.log(pxy[cls][fidx][f])  # categorical posterior
            for word in x_text[i][0]:
                if word not in pxy_[cls]:
                    prob += np.log(pxy_[cls]['<unk>']) / weight  # word not in vocabulary
                else:
                    prob += np.log(pxy_[cls][word]) / weight
            class_prob.append(prob)
        y_preds.append(class_prob)
    y_preds = softmax(y_preds)
    return y_preds

def predict(model, params, base_dir, weight_nb, weight_combine):
    # preprocess
    x_val, y_val = read_csv(base_dir+'/valid_features.csv'), read_csv(base_dir+'/valid_labels.csv')
    x_meta, (x_text, _), x_audio = splitFeatures(x_val)
    y_val = get_label(y_val)
    y_val = label2idx(y_val)
    x_audio = torch.Tensor(x_audio)

    # predict neural network output
    y_preds_nn = model(x_audio)
    y_preds_nn = softmax(y_preds_nn.data.numpy())

    # predict naive bayes output
    y_preds_nb = predict_nb(x_meta, x_text, params, weight_nb)
    y_preds_nb = softmax(y_preds_nb)

    # merge together
    numerator = weight_combine * y_preds_nn + (1 - weight_combine) * y_preds_nb
    denominator = np.sum(numerator, axis=1, keepdims=True)
    y_preds = numerator / denominator
    y_preds = np.argmax(y_preds, axis=1)[:, np.newaxis]

    return y_preds

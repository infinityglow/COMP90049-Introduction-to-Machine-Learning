import numpy as np
import torch
import torch.nn as nn
import torch.utils.data as Data
from torch.optim import Adam
from preprocess import *
from nn import Model

def p_y(y):
    class_counter = [0] * len(set(y))
    for cls in y:
        class_counter[cls] += 1
    return class_counter

def p_xy(x, y, alpha):
    prob_dict = {cls:{} for cls in y}
    # init dict (over classes) of dict (over features) of dict (over value counts)
    for c in prob_dict.keys():
        for f in range(len(x[0])):
            prob_dict[c][f] = {}
            if f < 3:
                prob_dict[c][f] = {'mu': 0, 'sigma': 0, 'data': []}  # numerical data
            else:
                vals = set([ins[f] for ins in x])
                prob_dict[c][f] = {v: alpha for v in vals}  # categorical data

    # fill in dictionary
    for idx, _ in enumerate(x):
        for fidx, _ in enumerate(x[idx]):
            if fidx < 3:
                prob_dict[y[idx]][fidx]['data'].append(x[idx][fidx])
            else:
                prob_dict[y[idx]][fidx][x[idx][fidx]] += 1

    # calculate mean and variance of numerical data and normalize categorical data plus Laplace smoothing
    for cls in prob_dict.keys():
        for f in prob_dict[cls].keys():
            if f < 3:
                prob_dict[cls][f]['mu'] = np.mean(prob_dict[cls][f]['data'])
                prob_dict[cls][f]['sigma'] = np.var(prob_dict[cls][f]['data'])
                prob_dict[cls][f].pop('data')  # for space saving
            else:
                for val in prob_dict[cls][f].keys():
                    prob_dict[cls][f][val] = prob_dict[cls][f][val] / (p_y(y)[cls] + len(prob_dict[cls][f])*alpha)
    return prob_dict



def p_xy_(x, vocab, y, alpha):
    prob_dict = {cls:{v: alpha for v in vocab.word2idx.keys()} for cls in y}
    for idx, ins in enumerate(x):
        lbl = y[idx]
        ins = ins[0]
        for word in ins:
            prob_dict[lbl][word] += 1
    # normalization
    prob_dict = {lbl: {w: freq/(sum(dict.values())+len(vocab)) for w, freq in dict.items()} for lbl, dict in prob_dict.items()}
    # same as follows
    # for lbl, dict in prob_dict.items():
    #     for w, freq in dict.items():
    #         prob_dict[lbl][w] = freq / (sum(dict.values())+len(vocab))
    # print(prob_dict)
    return prob_dict

def train_nb(x_train, y_train):
    x_meta, x_text, vocab = x_train
    py = p_y(y_train)
    pxy = p_xy(x_meta, y_train, alpha=1)
    pxy_ = p_xy_(x_text, vocab, y_train, alpha=1)

    return (py, pxy, pxy_)

def train_nn(x_train, y_train, batch_size, num_class, num_epoch, lr):
    # convert to torch.Tensor
    x_train, y_train = torch.Tensor(x_train), torch.LongTensor(y_train)
    # instantiate dataset and dataloader
    dataset = Data.TensorDataset(x_train, y_train)
    data_loader = Data.DataLoader(dataset=dataset,
                                  batch_size=batch_size,
                                  shuffle=True,
                                  num_workers=2)

    model = Model(x_train.shape[1], num_class)
    loss_fn = nn.CrossEntropyLoss()
    optim = Adam(model.parameters(), lr)

    for epoch in range(num_epoch):
        for _, (x_batch, y_batch) in enumerate(data_loader):
            y_preds = model(x_batch)
            loss = loss_fn(y_preds, y_batch)

            model.zero_grad()
            loss.backward()

            optim.step()

        acc = sum(torch.argmax(y_preds, dim=1)==y_batch) / float(batch_size)
        print("Epoch [{}/{}], Loss: {:.4f}, Acc: {:.2f}".format(epoch+1, num_epoch, loss.item(), acc))


    return model

def softmax(x):
    return np.exp(x) / np.sum(np.exp(x), axis=1, keepdims=True)

def train_main(x_train, y_train, batch_size, num_class, num_epoch, lr):
    x_meta, (x_text, vocab), x_audio = splitFeatures(x_train)
    y_train = get_label(y_train)
    y_train = label2idx(y_train)
    model = train_nn(x_audio, y_train, batch_size, num_class, num_epoch, lr)  # model parameters
    params = train_nb((x_meta, x_text, vocab), y_train)  # naive bayes parameters
    return model, params



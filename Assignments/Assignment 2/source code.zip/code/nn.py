import torch
import torch.nn as nn

class Model(nn.Module):
    def __init__(self, input_size, num_class):
        super(Model, self).__init__()
        self.linear = nn.Linear(input_size, num_class)

    def forward(self, features):
        out = (self.linear(features))
        return out


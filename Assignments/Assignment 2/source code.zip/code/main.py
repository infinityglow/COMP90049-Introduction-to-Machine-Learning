from train import train_main, train_nb
from validation import predict
from bagging import *
import torch


# hyper-parameters
base_dir = '../dataset'
BATCH_SIZE = 128
NUM_CLASS = 8
LR = 0.001
BAGGING_TIME = 10
MODEL_PATH = '../model/model_list'
PARAMS_PATH = '../model/params_list.npy'
HYPER_PARAMS_PATH = '../model/hyper_params_list.npy'


# tune hyperparameters
epoch_list = [50, 75, 100]
weight_nb_list = [1, 10, 100, 1000]
weight_combine_list = [i*0.1 for i in range(11)]


best_model_list = None
max_acc = best_epoch = best_weight_nb = best_weight_combine = 0

print('Validation Start!')
for epoch in epoch_list:
    for weight_nb in weight_nb_list:
        for weight_combine in weight_combine_list:
            print('batch_size: {:d}, epoch: {:d}, weight_nb: {:.2f}, weight_combine: {:.1f}'.format(BATCH_SIZE,
                                                                                                   epoch,
                                                                                                   weight_nb,
                                                                                                   weight_combine))
            y_preds_list = []
            model_list = []
            for i in range(BAGGING_TIME):
                x_train, y_train = sample('train')
                model, params = train_main(x_train, y_train, BATCH_SIZE, NUM_CLASS, epoch, LR)
                model_list.append(model)
                y_preds = predict(model, params, base_dir, weight_nb, weight_combine)
                y_preds_list.append(y_preds)
            acc = evaluate(y_preds_list, base_dir)

            print('validation accuracy: %.2f %%' % (acc*100))
            if acc > max_acc:
                best_model_list = model_list
                max_acc = acc; best_epoch = epoch; best_weight_nb = weight_nb; best_weight_combine = weight_combine

print('Maximum validation accuracy: %.2f' % max_acc)

print('Best hyper-parameters:')

print(' best epoch: %d\n best weight in naive bayes: %d\n best weight combination: %.1f' % (best_epoch, best_weight_nb, best_weight_combine))
hyper_params_dict = {'best_epoch': best_epoch, 'best_weight_nb': best_weight_nb, 'best_weight_combine': best_weight_combine}

# save hyper-parameters
np.save(HYPER_PARAMS_PATH, [hyper_params_dict])
print('Saved hyper-parameters to %s' % HYPER_PARAMS_PATH)

# global Naive Bayes parameters
x_train, y_train = read_csv(base_dir + '/train_features.csv'), read_csv(base_dir + '/train_labels.csv')
x_meta, (x_text, vocab), x_audio = splitFeatures(x_train)
y_train = get_label(y_train)
y_train = label2idx(y_train)
params = train_nb((x_meta, x_text, vocab), y_train)  # Naive Bayes parameters

# save Naive Bayes parameters
np.save(PARAMS_PATH, params)
print('Saved Naive Bayes parameters to %s' % PARAMS_PATH)

# save neural network parameters
torch.save({'model_%d' % i : best_model_list[i] for i in range(len(best_model_list))}, MODEL_PATH)
print('Saved neural network parameters to %s' % MODEL_PATH)